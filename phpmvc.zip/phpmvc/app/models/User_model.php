<?php  

class User_model {
	private $nama = 'Yuliana Wildan Ningrum';

	public function getUser()
	{
		return $this->nama;
	}
}