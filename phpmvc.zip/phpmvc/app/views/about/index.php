<div class="container">

	<h1 class="mt-4">About Me</h1>
	<img src="<?= BASEURL; ?>/img/profile.jpg" alt="Yuliana Wildan Ningrum" width="300" class="rounded-box">
	<p>Halo, nama saya <?= $data['nama']; ?>, umur saya <?= $data['umur']; ?> tahun, saya adalah seorang <?= $data['pekerjaan']; ?>.</p>

</div>